<?php
 $conn = mysqli_connect("localhost","root","","chat");
//  making two file in php folder one for signup and second one for configuration
//  in this condition we are giving server name username password and database name
if(!$conn){
echo"database connected" . mysqli_connect_error();// this "." point is string contenation operator
}


// else{    // we are checking the database is connected or not s.s.
//     echo"error";
// }
?>
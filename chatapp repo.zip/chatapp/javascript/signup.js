const form = document.querySelector(".signup form"),
continueBtn = form.querySelector(".button input");
errorText = form.querySelector(".error-txt");

form.onsubmit= (e)=>{
     e.preventDefault(); //preventing form to submitting
}


continueBtn.onclick = ()=>{
//  testing console is working or not
    // console.log("hello");

    // lets start --Ajaz--
    let xhr = new XMLHttpRequest(); // creating xml object
    xhr.open("POST","php/signup.php",true);
    // xhr opens takes many parameters but we only pass method ,url,and async
    xhr.onload = ()=>{
      if(xhr.readyState === XMLHttpRequest.DONE){
          if(xhr.status === 200){
              let data = xhr.response
             if (data == "success"){
                location.href = "users.php";
              } 
              else{
                errorText.textContent = data;
                errorText.style.display = "block";
              }
          }
      }
    }
    // we have to send the form through ajax to php
    let formData = new formData(form); //creating new form data object    

    xhr.send(formData);//sending form data to php
}
       // xhr.response gives us response of the passed url
              // console.log(data);//show response in console
            //   the response is coming from php file without  reloading page one of my most difficult challenge
const form = document.querySelector(".typing-area"),
inputField = form.querySelector(".input-field"),
sendBtn = form.querySelector("button"),
chatBox = document.querySelector(".chat-box");


sendBtn.onclick =() =>{
  let xhr = new XMLHttpRequest(); // creating xml object
  xhr.open("POST","php/chat.php",true);
  // xhr opens takes many parameters but we only pass method ,url,and async
  xhr.onload = ()=>{
    if(xhr.readyState === XMLHttpRequest.DONE){
        if(xhr.status === 200){
            let data = xhr.response;
          if (data == "success"){
            location.href = "users.php";
          } 
          else{
            errorText.textContent = data;
            errorText.style.display = "block";
          }
        }
    }
  }
  // we have to send the form through ajax to php
  let formData = new FormData(form); //creating new form data object    

  xhr.send(formData);//sending form data to php
}

const form = document.querySelector(".typing-area"),
inputField = document.querySelector(".input-field"),
sendBtn = form.querySelector("button"),
chatBox = document.querySelector(".chat-box");

form.onsubmit= (e)=>{
  e.preventDefault(); //preventing form to submitting
}

sendBtn.onclick = ()=>{
  let xhr = new XMLHttpRequest(); // creating xml object
  xhr.open("POST","php/insert-chat.php",true);
  // xhr opens takes many parameters but we only pass method ,url,and async
  xhr.onload = ()=>{
    if(xhr.readyState === XMLHttpRequest.DONE){
        if(xhr.status === 200){
          inputField.value = "";
          if (!chatBox.classList.contains("active")){
            // scrollToBottom();
          }
        }
    }
  }
  // we have to send the form through ajax to php
  let formData = new FormData(form); //creating new form data object    

  xhr.send(formData);//sending form data to php
}

// chatBox.onmouseenter =()=>{
//   chatBox.classList.add("active");
// }
// chatBox.onmouseleave =()=>{
//   chatBox.classList.remove("active");
// }


setInterval(()=>{
  let xhr = new XMLHttpRequest(); 
  xhr.open("POST","php/get-chat.php",true);
  xhr.onload = ()=>{
    if(xhr.readyState === XMLHttpRequest.DONE){
        if(xhr.status === 200){
            let data = xhr.response;
            chatBox.innerHTML = data;
            // if (!chatBox.classList.contains("active")){
            //   scrollToBottom();
            // }
        }
      }
    } 

    let formData = new FormData(form); //creating new form data object    

  xhr.send(formData);//sending form data to php
}, 500);

// function scrollToBottom(){
//   chatBox.scrollTop = chatBox.scrollHeight;
// }
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="signup.css">
    <title>Document</title>
</head>
<body>
<div class="box1"></div>
    <div class="box2"></div>
    <div class="wrapper">
        <section class="form login">
            <header>realtime chat app</header>
            <form action="#">
                <div class="error-txt">
</div>
<div class="field input">
<label>Email</label>
<input type="email" name="email" placeholder="enter your email">
</div>
<div class="field input">
<label>Password</label>
<input type="Password" name="password" placeholder="enter your Password">
</div>
<div class="field button">
<input type="submit" value="lets chat now!!">
</div>
</form>
<div class="link">NOT YET SIGNED  UP? <a href="index.php">signup</a></div>
</section>
</div>
<script src="javascript/login.js"></script>
</body>
</html>
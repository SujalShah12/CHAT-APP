<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="signup.css">
    <script src="https://kit.fontawesome.com/59c9b6e267.js" crossorigin="anonymous"></script>
    <title>Document</title>
</head>
<body>
<div class="box1"></div>
    <div class="box2">
        <img src="img/socialmam.png" alt="">
    </div>
    <div class="wrapper">
        <section class="form signup">
            <header>Chat now</header>
            <form action="#" enctype="multipart/from-data">
                <div class="error-txt"></div>
<div class="name-details">
<div class="field input">
<label>First name</label>
<input type="text" name="fname" placeholder="enter your first name" required>          
</div>
<div class="field input">
<label>Last name</label>
<input type="text" name="lname" placeholder="enter your last name" required>
</div>
</div>
<div class="field input">
<label>Email</label>
<input type="email" name="email" placeholder="enter your email" required>
</div>
<div class="field input">
<label>Password</label>
<input type="Password" name="password" placeholder="enter new Password" required>
</div>
<div class="field image">
<label>Select image</label>
<input type="file" name="image" required>
</div>
<div class="field button">
<input type="submit" value="lets chat now!!">
</div>
</form>
<div class="link">ALREADY SIGNED  UP? <a href="login.php">login now</a></div>
</section>
</div>
<script src="javascript/signup.js"></script>
</body>
</html>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <link rel="stylesheet" href="signup.css">
   <script src="https://kit.fontawesome.com/59c9b6e267.js" crossorigin="anonymous"></script>
    <title>Document</title>
</head>